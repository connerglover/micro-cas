Pinned WebTILP and linked dependency source. The tilibs archive contains
webtilp/build_wasm_deps.sh, patches, build instructions and licenses.
Deployment build records accompany the installer under vendor/.
